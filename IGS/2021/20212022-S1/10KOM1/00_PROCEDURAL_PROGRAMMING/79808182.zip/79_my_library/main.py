import math
import myMath

print(math.pi) #3.14159
print(math.sqrt(4)) #2.0


print(myMath.gravitasi_bumi)
print(myMath.pangkat_tiga(10))