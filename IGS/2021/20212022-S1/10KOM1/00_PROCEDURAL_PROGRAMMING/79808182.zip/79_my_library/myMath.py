
gravitasi_bumi = 9.8

def pangkat_tiga(angka):
	return angka**3