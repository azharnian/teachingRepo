"""
import hitungan.mtk
import hitungan.fis

print(hitungan.mtk.phi)
print(hitungan.fis.gravitasi)

"""
from hitungan import mtk, fis

print(mtk.phi)
print(fis.gravitasi)