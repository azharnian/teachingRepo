function setup(){
	createCanvas(500, 500);
}

function draw() {
	background(120);
	fill(255, 0, 0);
	noStroke();
	ellipse(250, 250, 200, 200);
}